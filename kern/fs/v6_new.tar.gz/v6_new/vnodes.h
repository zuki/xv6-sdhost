
#ifndef KERNEL_FS_V6_vnodes_H
#define KERNEL_FS_V6_vnodes_H

#include <types.h>
#include <string.h>
#include <linux/stat.h>
#include <vfs.h>
#include <mm.h>
#include <queue.h>
#include <spinlock.h>

#include "v6.h"
#include "fs.h"
#include "inodes.h"

#define MAX_VNODES    50

#define V6_QUEUE_NODE_TO_VNODE(node) \
            ((struct vnode *) (((char *) node) - sizeof(struct vnode)))

static int nodes_in_cache;
static struct queue vnode_cache;
static struct slab_cache *V6VNODE;
extern struct vnode_ops v6_vnode_ops;

static void release_unused_vnodes();

static void init_v6_vnodes()
{
    nodes_in_cache = 0;
    _queue_init(&vnode_cache);
    V6VNODE = slab_cache_create("v6_vnode", sizeof(struct v6_vnode), 0);
}

static void sync_vnodes()
{
    struct vnode *vnode;
    acquire(&vnode_cache.lock);
    for (struct queue_node *cur = vnode_cache.head; cur; cur = cur->next) {
        vnode = V6_QUEUE_NODE_TO_VNODE(cur);
        release(&vnode_cache.lock);
        acquiresleep(&vnode->lock);
        if (vnode->bits & VBF_DIRTY)
            write_inode(vnode, vnode->ino);
        releasesleep(&vnode->lock);
        acquire(&vnode_cache.lock);
    }
    release(&vnode_cache.lock);
}

static struct vnode *load_vnode(struct mount *mp, inode_t ino)
{
    int error;
    struct buf *buf;
    struct vnode *vnode;

    release_unused_vnodes();

    // TODO: _find_free_entry()の実装
    //entry = _find_free_entry();
    vnode = slab_cache_alloc(V6VNODE);
    if (!vnode)
        return NULL;

    _queue_insert(&vnode_cache, &V6_DATA(vnode).node);

    vfs_init_vnode(vnode, &v6_vnode_ops, mp, 0, 1, 0, 0, 0, ino, 0, 0, 0, 0);
    for (char j = 0; j < V6_NDIRECT+2; j++)
        V6_DATA(vnode).addrs[j] = 0;

    error = read_inode(vnode, ino);
    if (error) {
        slab_cache_free(V6VNODE, vnode);
        return NULL;
    }

    nodes_in_cache += 1;
    return vnode;
}

static struct vnode *get_vnode(struct mount *mp, inode_t ino)
{
    struct vnode *vnode;

    for (struct queue_node *cur = vnode_cache.head; cur; cur = cur->next) {
        vnode = V6_QUEUE_NODE_TO_VNODE(cur);
        //printk("S:%x;%d;%d\n", vnode, vnode->mp->dev, vnode->ino);
        if (vnode->mp->dev == mp->dev && vnode->ino == ino) {
            //printk("G:%x;%d;%d\n", vnode, mp->dev, ino);
            vfs_clone_vnode(vnode);

            // Move to the front of the vnode_cache list
            _queue_remove(&vnode_cache, &V6_DATA(vnode).node);
            _queue_insert(&vnode_cache, &V6_DATA(vnode).node);
            return vnode;
        }
    }

    return load_vnode(mp, ino);
}

static struct vnode *alloc_vnode(struct mount *mp, mode_t mode, uid_t uid, gid_t gid, device_t device)
{
    struct vnode *vnode;

    bitnum_t ino = alloc_inode(V6_SUPER(mp->super), mode, uid, gid, device);
    if (!ino)
        return NULL;

    vnode = load_vnode(mp, ino);
    if (!vnode) {
        free_inode(V6_SUPER(mp->super), ino);;
        return NULL;
    }

    return vnode;
}

static void mark_vnode_dirty(struct vnode *vnode)
{
    vnode->bits |= VBF_DIRTY;
}

static int delete_vnode(struct vnode *vnode)
{
    free_inode(V6_SUPER(vnode->mp->super), vnode->ino);
    vnode->ino = 0;
    return 0;
}

static int release_vnode(struct vnode *vnode)
{
    if (vnode->ino && vnode->bits & VBF_DIRTY)
        write_inode(vnode, vnode->ino);
    _queue_remove(&vnode_cache, &V6_DATA(vnode).node);
    kmfree(vnode);
    nodes_in_cache -= 1;
    return 0;
}

static void release_unused_vnodes()
{
    struct queue_node *last;

    while (nodes_in_cache - 1 >= MAX_VNODES) {
        for (last = vnode_cache.tail; last && V6_QUEUE_NODE_TO_VNODE(last)->refcount > 0; last = last->prev) { }
        if (!last || V6_QUEUE_NODE_TO_VNODE(last)->refcount > 0)
            break;
        release_vnode(V6_QUEUE_NODE_TO_VNODE(last));
    }
}


#endif
