
#ifndef KERN_FS_V6_BITMAPS_H
#define KERN_FS_V6_BITMAPS_H

#include <types.h>
#include "v6.h"
#include "../bufcache.h"

typedef int bitnum_t;

static inline char bit_mask(char bits)
{
    char byte = 0x00;
    for (short j = 0; j < bits; j++)
        byte = (byte << 1) | 0x01;
    return byte;
}

//int bitmap_init(device_t dev, uint32_t bitmap_start, int bitmap_size, int num_entries, short reserve);
bitnum_t bit_alloc(device_t dev, uint32_t bitmap_start, int bitmap_size, uint32_t near);
int bit_free(device_t dev, uint32_t bitmap_start, bitnum_t bitnum);

#endif
