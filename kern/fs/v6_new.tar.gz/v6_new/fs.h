#ifndef INC_FS_V6_FS_H
#define INC_FS_V6_FS_H

#include <types.h>
#include <vfs.h>
#include <param.h>
#include <linux/stat.h>

#define V6_BLKSIZE      4096        /* ブロックサイズ */
#define V6_SECSIZE      512         /* セクタサイズ */
#define V6_BLKSECT      (V6_BLKSIZE / V6_SECSIZE)   /* ブロックあたりのセクタ数 */

#define V6_FSSIZE       1000        /* ファイルシステムのサイズ（ブロック単位） */

#define V6_LOGSIZE      30          /* ログサイズ（ブロック単位）（未使用） */
#define V6_ROOTINO      1           /* v6ファイルシステムのルートのinode番号 */

#define V6_NDIRECT      11                               /* 直接指定のブロック数 */
#define V6_NINDIRECT      (V6_BLKSIZE / sizeof(uint32_t))  /* 第1間接指定のブロック数 */
#define V6_NINDIRECT2     (V6_NINDIRECT * V6_NINDIRECT)        /* 第2間接指定のブロック数 */
#define V6_MAXFILE      (V6_NDIRECT + V6_NINDIRECT + V6_NINDIRECT2)  /* 1ファイルの最大ブロック数 */
                                                    /* 11 + 1024 + 1,048,576 = 1,049,611 : * 4096 = 4100 MB */

/* ブロックあたりのinode数 (4096 / 128 = 32): Inodes per block : V6_INODES_PER_ZONE */
#define V6_IPB              (V6_BLKSIZE / sizeof(struct v6_dinode))

/* inode iが含まれるブロック番号 */
#define V6_IBLOCK(i, sb)    ((i) / V6_IPB + (sb).inodestart)

// FIXME: data blockもbtmap blockも1ファイルの最大サイズに比べ少なすぎる
/* Bitmapブロックのビット数/ブロック = 32,768 : V6_BITS_PER_ZONE */
#define V6_BPB              (V6_BLKSIZE * 8)

/* ブロック b を記録する未使用マップのあるブロック */
#define V6_BBLOCK(b, sb)    (b/V6_BPB + (sb).bmapstart)

// FIXME: これは現在のテスト環境での数値
#define V6_BOOT_ZONE                0
#define V6_SUPER_ZONE               1
#define V6_LOG_ZONES                30
#define V6_INODE_ZONES              4
#define V6_BITMAP_ZONES             1
#define V6_LOG_START(super)         ((super)->logstart)
#define V6_INODE_START(super)       ((super)->inodestart)
#define V6_BITMAP_START(super)      ((super)->bmpastart)
#define V6_DATA_START(super)        (V6_BITMAP_START + V6_BITMAP_ZONES)

/* 最大リンク数 */
#define V6_MAXLINK 100

/* v6固有のファイルタイプ */
#define T_DIR       1   // ディレクトリ
#define T_FILE      2   // 通常ファイル
#define T_DEV       3   // ブロックデバイス
#define T_CHR       4   // キャラクタデバイス
#define T_SYMLINK   5   // シンボリックリンク
#define T_SOCK      6   // ソケット
#define T_FIFO      7   // FIFO
#define T_UNKNOWN   8

static inline uint16_t mode2v6type(mode_t mode)
{
    int type = mode & S_IFMT;
    select (type) {
        case S_IFDIR:   return T_DIR;
        case S_IFCHR:   return T_CHR;
        case S_IFBLK:   return T_DEV;
        case S_IFREG:   return T_FILE;
        case S_IFLNK:   return T_SYMLINK;
        case S_IFSOCK:  return T_SOCK;
        case S_IFIFO:   return T_FIFO;
    }
    return T_UNKNOWN;
}

/* v6ファイルシステムのディスクレイアウト:
 * [ boot block | super block | log | inode blocks | free bit map | data blocks ]
 *   1 (4096)     1 (4096)      30    4 (16,384)     1 (4096)       963
 * usr/mkfs で作成
 */
struct v6_superblock {
  uint32_t size;         // v6 fs imageのブロック単位のサイズ       0x03e8
  uint32_t nblocks;      // データブロック数                        0x03c3
  uint32_t ninodes;      // dinode (= inode) 数                     0x00c8
  uint32_t nlog;         // ログブロック数（領域は取るが未使用）    0x001e
  uint32_t logstart;     // ログブロックの開始ブロック番号          0x0002
  uint32_t inodestart;   // inodeブロックの開始ブロック番号         0x0020
  uint32_t bmapstart;    // freeマップブロックの開始ブロック番号    0x0024
};

/* On-disk inode構造体 : 128バイト */
struct v6_inode {
    uint16_t            type;       //  0: V6ファイルタイプ : T_XXX
    uint16_t            nlink;      //  2: ハードリンク数
    device_t            rdev;       //  4:デバイス番号
    uint32_t            size;       //  8: Size of file (bytes)
    mode_t              mode;       // 12: file mode
    uid_t               uid;        // 16: owner's user id
    gid_t               gid;        // 20: owner's gropu id
    struct timespec     atime;      // 24: last accessed time
    struct timespec     mtime;      // 40: last modified time
    struct timespec     ctime;      // 56: created time
    uint32_t addrs[V6_NDIRECT+2];   // 72: Data block addresses
    char             _dummy[4];     // 124:
};

#endif
