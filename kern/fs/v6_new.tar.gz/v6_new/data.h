
#ifndef KERN_FS_V6_DATA_H
#define KERN_FS_V6_DATA_H

#include <types.h>
#include "v6.h"
#include "fs.h"
#include "../bufcache.h"

#define MFS_LOOKUP_ZONE		0
#define MFS_CREATE_ZONE		1

/* データを保存するブロック番号を割り当てる */
static uint32_t v6_alloc_datablock(struct v6_super *super)
{
    int b, bi, m;
    struct buf *bp;

    bp = 0;
    for (b = 0; b < super->sb.size; b += V6_BPB) {
        bp = get_block(super->dev, V6_BBLOCK(b, super->sb));
        for (bi = 0; bi < V6_BPB && b + bi < super->sb.size; bi++) {
            m = 1 << (bi % 8);
            if ((bp->block[bi / 8] & m) == 0) {  // Is block free?
                bp->block[bi / 8] |= m;  // Mark block in use.
                put_block(bp);
                release_block(bp, 0);
                v6_bzero(b, b + bi);
                return b + bi;
            }
        }
        release_block(bp, 0);
    }
    panic("balloc: out of blocks");

    return 0;
}

/* bitmapを解放する */
static void minix_free_datablock(struct v6_super *super, uint32_t bno)
{
    struct buf *bp;
    int bi, m;

    bp = get_block(super->dev, V6_BBLOCK(bno, super->sb));
    bi = bno % V6_BPB;
    m = 1 << (bi % 8);
    if ((bp->block[bi / 8] & m) == 0)
        panic("freeing free block");
    bp->block[bi / 8] &= ~m;
    put_block(bp);
    release_block(bp, 0);
}

/* */
static int32_t data_lookup(struct vnode *vnode, int32_t bno, char create)
{
    struct v6_super *super = V6_SUPER(vnode->mp->super);
    uint32_t idx1, idx2, addr, *a;
    struct buf *bp;

    if (bno < V6_NDIRECT) {
        if ((addr = V6_DATA(vnode).addrs[bno]) == 0)
            V6_DATA(vnode).addrs[bno] = addr = v6_balloc(vnode->rdev);
        return addr;
    }
    bno -= V6_NDIRECT;

    if (bno < V6_NINDIRECT) {
        // Load indirect block, allocating if necessary.
        if ((addr = V6_DATA(vnode).addrs[V6_NDIRECT]) == 0) {
            addr = v6_balloc(vnode->rdev);
            if (addr == 0)
                return 0;
            V6_DATA(vnode).addrs[V6_NDIRECT] = addr;
        }
        bp = get_block(vnode->rdev, addr);
        a = (uint32_t*)bp->block;
        if ((addr = a[bno]) == 0) {
            addr = v6_balloc(vnode->rdev);
            if (addr == 0)
                return 0;
            a[bno] = addr;
            put_block(bp);
        }
        trace("bno: %d, addr: 0x%llx", bno, addr);
        release_block(bp, 0);
        return addr;
    }

    bno -= V6_NINDIRECT;

    if (bno < V6_NINDIRECT2) {
        // Load indirect block, allocating if necessary.
        if ((addr = V6_DATA(vnode).addrs[V6_NDIRECT+1]) == 0) {
            addr = v6_balloc(vnode->rdev);
            if (addr == 0)
                return 0;
            V6_DATA(vnode).addrs[V6_NDIRECT+1] = addr;
        }
        idx1 = bno / V6_NINDIRECT;
        idx2 = bno % V6_NINDIRECT;
        bp = get_block(vnode->rdev, addr);
        a = (uint32_t*)bp->block;
        if ((addr = a[idx1]) == 0) {
            addr = v6_balloc(vnode->rdev);
            if (addr == 0)
                return 0;
            a[idx1] = addr;
            put_block(bp);
        }
        trace("idx1: %d, addr1: 0x%llx", idx1, addr);
        put_block(bp);
        release_block(bp, 0);
        bp = get_block(vnode->rdev, addr);
        a = (uint32_t*)bp->block;
        if ((addr = a[idx2]) == 0) {
            addr = v6_balloc(vnode->rdev);
            if (addr == 0)
                return 0;
            a[idx2] = addr;
            put_block(bp);
        }
        trace("idx2: %d, addr2: 0x%llx", idx2, addr);
        release_block(bp, 0);
        return addr;
    }
    panic("bmap: out of range");
    return 0;
}

static void zone_free_all(struct vnode *vnode)
{
	zone_t zone;

	// NOTE this can only be used with files or empty directories

	// If this is a device file, then the zone is the device number, so just return
	if (S_ISDEV(vnode->mode))
		return;

	// Traverse all zones and free each
	for (zone_t znum = 0; zone = zone_lookup(vnode, znum, MFS_LOOKUP_ZONE); znum++)
		minix_free_zone(MINIX_SUPER(vnode->mp->super), zone);

	// Go through the tier 2 zonenum tables and free each
	if (MINIX_DATA(vnode).zones[8]) {
		struct buf *buf = get_block(MINIX_SUPER(vnode->mp->super)->dev, from_le16(MINIX_DATA(vnode).zones[8]));
		if (buf) {
			minix_v1_zone_t *entries = buf->block;
			for (zone_t i = 0; i < MINIX_V1_ZONENUMS_PER_ZONE; i++) {
				if (entries[i])
					minix_free_zone(MINIX_SUPER(vnode->mp->super), from_le16(entries[i]));
			}
			release_block(buf, 0);
		}
	}

	// Go through the tier 1 zonenum tables and free each
	for (char i = MINIX_V1_TIER1_ZONENUMS; i < MINIX_V1_TOTAL_ZONENUMS; i++) {
		if (MINIX_DATA(vnode).zones[i])
			minix_free_zone(MINIX_SUPER(vnode->mp->super), from_le16(MINIX_DATA(vnode).zones[i]));
	}

	// Go through the tier 0 zonenum tables (the inode zones) and free each
	for (char i = 0; i < MINIX_V1_TOTAL_ZONENUMS; i++)
		MINIX_DATA(vnode).zones[i] = 0;

	mark_vnode_dirty(vnode);
}

#endif
