
#ifndef KERNEL_FS_V6_V6_H
#define KERNEL_FS_V6_V6_H

#include <types.h>
#include <vfs.h>
#include <sleeplock.h>

#include "fs.h"
#include <queue.h>

#define V6_SUPER(super)     ((struct v6_super *) (super))
#define V6_VNODE(vnode)     ((struct v6_vnode *) (vnode))
#define V6_DATA(vnode)      (((struct v6_vnode *) (vnode))->data)

#define MBF_DIRTY        0x0001

struct v6_super {
    device_t dev;
    char max_filename;

    union {
        struct v6_superblock sb;
    };
};

struct v6_vnode_data {
    struct queue_node node;
    uint32_t addrs[V6_NDIRECT+2];
};

struct v6_vnode {
    struct vnode vn;
    struct sleeplock lock;
    struct v6_vnode_data data;
};

int v6_init();
int v6_mount(struct mount *mp, device_t dev, struct vnode *parent);
int v6_unmount(struct mount *mp);
int v6_sync(struct mount *mp);
int v6_load_superblock(device_t dev);

int v6_create(struct vnode *vnode, const char *filename, mode_t mode, uid_t uid, struct vnode **result);
int v6_mknod(struct vnode *vnode, const char *name, mode_t mode, device_t dev, uid_t uid, struct vnode **result);
int v6_lookup(struct vnode *vnode, const char *name, struct vnode **result);
int v6_link(struct vnode *oldvnode, struct vnode *newparent, const char *filename);
int v6_unlink(struct vnode *parent, struct vnode *vnode, const char *filename);
int v6_rename(struct vnode *vnode, struct vnode *oldparent, const char *oldname, struct vnode *newparent, const char *newname);
int v6_truncate(struct vnode *vnode);
int v6_update(struct vnode *vnode);
int v6_release(struct vnode *vnode);

int v6_open(struct vfile *file, int flags);
int v6_close(struct vfile *file);
int v6_read(struct vfile *file, char *buf, size_t nbytes);
int v6_write(struct vfile *file, const char *buf, size_t nbytes);
int v6_ioctl(struct vfile *file, unsigned int request, void *argp, uid_t uid);
offset_t v6_seek(struct vfile *file, offset_t position, int whence);
int v6_readdir(struct vfile *file, struct dirent *dir);


#endif
