
#include <types.h>
#include <string.h>

#include "fs.h"
#include "v6.h"
#include "bitmaps.h"

/* bitmapブロックを初期化する :mkfsで使う関数 */
#if 0
int bitmap_init(device_t dev, int32_t bitmap_start, int bitmap_size, int num_entries, short reserve)
{
	char *block;
	struct buf *buf;

	// num_entries ビットのみを空きとして設定し、ブロックの残りを（割当不可の）予約領域とする
    for (int i = bitmap_start; i < bitmap_start + bitmap_size; i++) {
		buf = get_block(dev, i);
		if (!buf)
			return -1;
		block = buf->block;

		if (num_entries < V6_BPB) {
			int bytes = (num_entries >> 3);
			char bits = (num_entries & 0x07);

			if (bits)
				bytes += 1;
			memset(block, 0x00, bytes);
			if (bits)
				block[bytes - 1] = ~bit_mask(bits);
			memset(&block[bytes], 0xFF, V6_BLKSIZE - bytes);
			break;
		}
		else
			memset(block, 0x00, V6_BLKSIZE);
		num_entries -= V6_BPB;

		release_block(buf, BCF_DIRTY);
	}

	buf = get_block(dev, bitmap_start);
	if (!buf)
		return -1;
	block = buf->block;

	// Reserve entries at the beginning of table
	short i = 0;
	for (; i < (reserve >> 3); i++)
		block[i] = 0xFF;
	block[i] = bit_mask(reserve & 0x7);

	release_block(buf, BCF_DIRTY);
	return 0;
}
#endif

/* bitmapブロックから空いている最初のブロック番号を返す */
 bit_alloc(device_t dev, int32_t bitmap_start, int bitmap_size, int32_t near)
{
    int b, bi, m;
    struct buf *bp;

    bp = 0;
    for (b = 0; b < V6SB.size; b += BPB) {
        bp = get_block(dev, BBLOCK(b, V6SB));
        for (bi = 0; bi < BPB && b + bi < V6SB.size; bi++) {
            m = 1 << (bi % 8);
            if ((bp->data[bi / 8] & m) == 0) {  // Is block free?
                bp->data[bi / 8] |= m;  // Mark block in use.
                put_block(bp);
                release_block(bp);
                v6_bzero(dev, b + bi);
                return b + bi;
            }
        }
        release_block(bp);
    }
    panic("balloc: out of blocks");

    int ino;
    struct buf *bp;

    for (ino = 0; ino < V6SB.ninodes; ino++) {
    bp = get_block(dev, IBLOCK(ino, V6SB));
    dip = (struct v6_dinode *)bp->data + ino % IPB;
    if (dip->type == 0) {   // a free inode
        memset(dip, 0, sizeof(*dip));
        dip->type = type;
        put_block(bp);      // mark it allocated on the disk
        release_block(bp);
        return v6_iget(dev, ino);
    }
    release_block(bp);

	char bit;
	char *block;
	int zone = 0;
	struct buf *buf;

	for (; zone < bitmap_size; zone++) {
		buf = get_block(dev, bitmap_start + zone);
		if (!buf)
			return 0;
		block = buf->block;

		for (int i = 0; i < MINIX_V1_ZONE_SIZE; i++) {
			//printk("Bitsearch %d: %x\n", i, block[i]);
			if ((char) ~block[i]) {
				for (bit = 0; bit < 8 && ((0x01 << bit) & block[i]); bit++) { }
				block[i] |= (0x01 << bit);
				release_block(buf, BCF_DIRTY);
				return bit + (i * 8) + (zone * MINIX_V1_ZONE_SIZE * 8);
			}
		}

		release_block(buf, 0);
	}

	return 0;
}

int bit_free(device_t dev, int32_t bitmap_start, bitnum_t bitnum)
{
	int32_t zone = (bitnum >> 3) / MINIX_V1_ZONE_SIZE;
	int i = (bitnum >> 3);
	char bit = (bitnum & 0x7);
	struct buf *buf = get_block(dev, bitmap_start + zone);
	if (!buf)
		return -1;
	char *block = buf->block;

	block[i] &= ~(0x01 << bit);
	release_block(buf, BCF_DIRTY);
	return 0;
}
